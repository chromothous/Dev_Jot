Dev Jot

Dev Jot is a Python desktop application for managing and organizing code snippets. It allows you to create, edit, search, and view snippets in multiple programming languages with optional syntax highlighting.

Features

Create, edit, and delete code snippets

Search snippets by title, description, or code

Syntax highlighting for multiple languages

Organized hub view with snippet cards

Installation

Run the executable in the dist folder. No additional dependencies are required.

Usage

Launch the application

Create snippets

Use the search bar to find snippets

Click a snippet card to view or edit

Requirements

Windows 10 or newer

Python is not required to run the executable